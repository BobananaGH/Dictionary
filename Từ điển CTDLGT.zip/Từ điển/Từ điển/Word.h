#pragma once

#include <string>
#include <iostream>

using namespace std;

class Word {
private:
    string english;
    string vietnamese;

public:
    Word(string eng = "", string viet = "");

    string getEnglish() const;
    string getVietnamese() const;
    void setVietnamese(string viet);

    char getFirstChar() const;
    bool equals(string otherEng) const;
    void print() const;
};