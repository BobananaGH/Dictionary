#pragma once

#include "Word.h"

struct Node {
    Word data;
    Node* next;

    Node(Word w) : data(w), next(NULL) {}
};