#include "Application.h"

int main() {
    Application app;
    app.run();
    return 0;
}